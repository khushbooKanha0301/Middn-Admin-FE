const apiConfigs = {
  ENV: `${process.env.REACT_APP_ENV}`,
  API_URL: `${process.env.REACT_APP_API_URL}`,
  BASE_URL: `${process.env.REACT_APP_API_URL}`,
}
export default apiConfigs
